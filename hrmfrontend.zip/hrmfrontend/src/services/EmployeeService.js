import axios from "axios";

const APPLICATION_BASE_URL='http://localhost:8080/api/';

class EmployeeService{

    getAllEmployees()
    {
        return axios.get(APPLICATION_BASE_URL);
    }

    getEmployeeById(empId)
    {
        return axios.get(APPLICATION_BASE_URL+empId);

    }

    createEmployee(employee)
    {
        return axios.post(APPLICATION_BASE_URL,employee);

    }

    updateEmployee(empId,employee)
    {
        return axios.put(APPLICATION_BASE_URL +empId,employee);
    }

    deleteEmployee(empId)
    {
        return axios.delete(APPLICATION_BASE_URL+empId);
    }

}

export default new EmployeeService();